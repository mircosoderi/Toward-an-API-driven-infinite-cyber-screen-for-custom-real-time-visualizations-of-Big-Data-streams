0. Choose a name for your Service Node
1. In data/mycert.cnf, set commonName and DNS.1 equal to the name choosen at step 0
2. Run data/mycert.bat
3. Tar the data folder.
4. Edit create.bat, setting the port mapping, the Docker network, and the volume and container names (set these last ones equal to the name choosen at step 0).
5. Run create.bat, or copy its content to a Linux shell and run from there
6. Stop the container that you have started at step 5
7. Edit restore.bat, setting the volume name equal to the name choosen at step 0, and the path equal to the folder where the tar archive created at step 3 locates
8. Run restore.bat, or copy its content to a Linux shell and run from there